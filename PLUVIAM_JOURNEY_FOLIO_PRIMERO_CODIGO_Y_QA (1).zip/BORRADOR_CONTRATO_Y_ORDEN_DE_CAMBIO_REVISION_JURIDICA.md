# PLUVIAM — Borrador de condiciones para contrato de proyecto personalizado
**USO INTERNO · REVISIÓN LEGAL OBLIGATORIA · NO FIRMAR NI PUBLICAR COMO VIGENTE.** Contiene propuestas comerciales y escenarios; debe adaptarse al caso, régimen fiscal, responsable legal, legislación local y obligaciones aplicables del consumidor. No es asesoría legal personalizada.

## Carátula obligatoria, completar antes de presentar al cliente
- Prestador real y titular contractual/fiscal: **[NOMBRE COMPLETO Y RAZÓN O DENOMINACIÓN EFECTIVAMENTE CONSTITUIDA]**; RFC **[PENDIENTE]**; domicilio **[PENDIENTE]**; datos de contacto **[PENDIENTE]**.
- Cliente, inmueble y titular autorizado: **[DATOS BAJO CONSENTIMIENTO Y CANAL PRIVADO]**.
- Folio expediente y versión de oferta; lugar/fecha de firma; vigencia REAL de la propuesta; documentos anexos; medio verificable de firma y conservación íntegra.
- Ingeniería: capacidad, componentes, calidad de agua y **usos autorizados** por el proyecto. No prometer consumo humano sin validación adecuada.
- Monto total incluyendo impuestos o especificación fiscal aplicable, entregables incluidos/excluidos, mano de obra y garantía.

## Desglose y aceptación de hitos
Elegir **UNO** expresamente, con montos exactos que sumen el total:
- [ ] **50/50:** 50% de anticipo antes de compras/instalación; 50% contra el hito QA/entrega especificado, con mecanismo de aceptación y revisión de observaciones.
- [ ] **50/30/20:** 50% de anticipo antes de compras/instalación; 30% tras evidencia y notificación del hito de instalación acordado; 20% contra pruebas/entrega y aceptación en términos acordados.
En ambos casos, identificar qué actividades se realizan ANTES de pago como parte del diagnóstico/venta; precisar cronograma sujeto a permisos y disponibilidad, tolerancias, circunstancias de retraso, controles de cambios, fechas y pruebas objetivas.

## Obra civil preexistente y cambio de alcance
Las revisiones a elementos accesibles no garantizan buen estado de tuberías ocultas, impermeabilización o estructuras preexistentes. Si surge necesidad de obra adicional, el prestador debe documentar el hallazgo, explicar riesgo/alternativas, costo y plazo, y obtener **aprobación separada por escrito antes de ejecutar y facturar**; el consumidor conserva sus derechos ante errores imputables al prestador.

## Clima y usos
El volumen pluvial depende de superficie útil, precipitación efectiva y estacionalidad. El cálculo de la web es estimativo y no garantiza suministro, ahorro o autonomía. El diseño final especificará rendimiento de referencia, desviaciones, mantenimiento, separación de redes y seguridad sanitaria por uso.

## Permisos
Las partes acuerdan identificar autorizaciones de administración de condominio, municipales, del propietario y técnicas. Debe explicarse quién solicita, aporta o valida cada permiso. No comenzar obra cuando un permiso necesario está pendiente; efectos y cancelación sujetos a acuerdos proporcionados y ley.

## Mantenimiento y garantía
Entregar instrucciones de operación, periodicidades, pruebas y garantía. El contrato indicará garantía aplicable de instalación y componentes, causas técnicas comprobables de falla o mal uso, y canales de reclamación. **Nunca condicionar o eliminar por defecto derechos legales de garantía porque el cliente no haya contratado un plan opcional de mantenimiento.**

## Impago, cambio, suspensión y cancelación
Antes de vender debe existir procedimiento de recordatorio escrito, plazo de subsanación razonable, documentación de trabajos efectivamente hechos, opciones de reprogramación/rescisión y ajuste/reembolso proporcional, así como reciprocidad ante incumplimiento del prestador. **No dejar infraestructura en estado peligroso ni bloquear filtración, abastecimiento, válvulas, seguridad o derechos de garantía para presionar el pago.** Todo cargo por cancelación o demora deberá ser razonable, justificable, recíproco y revisado por asesoría jurídica.

## Entrega y aceptación
Acta de pruebas y evidencias de estanqueidad, controles hidráulicos, conexiones separadas, equipos, caudal según diseño, manuales y acciones correctivas. Si hay observaciones, documentar plazo y responsable; el pago del hito final se rige por lo acordado y los derechos del consumidor. La instalación debe ser segura para el uso declarado. Software/telemetría opcionales requieren contrato específico, prestación realmente disponible y consentimiento.

## Facturación, privacidad y comunicaciones
El checkout registra pago de hito aprobado pero **no sustituye CFDI**, recibo del procesador ni acta de entrega. Explicar datos tratados, responsable real, ARCO y proveedor de pagos en aviso integral aprobado. El permiso para llamadas o WhatsApp comerciales va por separado; el correo estrictamente transaccional se limita a la relación contractual.

## Verificación por jurídico y finanzas
[ ] identidad fiscal/prestador real; [ ] revisión del modelo Profeco/registro aplicable y equidad de las cláusulas; [ ] IVA/CFDI; [ ] régimen de garantías; [ ] privacidad integral; [ ] firma/autenticidad/retención; [ ] pago/reembolsos; [ ] dos RFQ y BOM; [ ] protección sanitaria; [ ] responsables de permisos; [ ] aceptación CEO.

**Fuentes de consulta:** https://www.gob.mx/profeco/documentos/contratos-de-adhesion-informate-antes-de-firmar ; https://www.ordenjuridico.gob.mx/Documentos/Federal/html/wo125102.html .
