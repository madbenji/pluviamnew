# PLUVIAM V51 — Módulo Retell AI aditivo sobre V50

**NO DESPLEGADO · PREPRODUCCIÓN · RETELL DESACTIVADO POR DEFECTO**

Base exacta: paquete **PLUVIAM_V50_CODIGO_COMPLETO_Y_QA.zip** derivado de V46-R7, mantenido bajo `baseline/V50_CODIGO_FUENTE_COMPLETO_ORIGINAL.zip` en la entrega V51.

## Directorios

- `site/`: sitio Cloudflare Pages, `_worker.js` conserva el flujo V50 con tres integraciones pequeñas: `/api/lead-abandonment` autenticado, campo `retellFollowup` de `/api/proyecto`, cancelación en `paidOutbox` y lectura autorizada de `/api/admin/retell`. La política de pagos original permanece igual.
- `retell-worker/`: Worker Cron separado para salida Retell y conciliación de estados de llamadas. Sin nuevas bibliotecas ni segundo CRM.
- `backend/`: módulo Retell independiente como fuente legible, incorporado en el Worker de Pages (archivo único, apto para despliegue ZIP de Pages Advanced Mode).
- `migraciones/002_retell_v51.sql`: D1 aditiva, aislada de la migración opcional 001.
- `docs/RETELL_V51_IMPLEMENTACION.md`: documentación detallada, variables, preparación, seguridad, QA, costos, desactivación y reversión.
- `docs/VALERIA_GUION_Y_CONSENTIMIENTO.md`: guion IA y texto de consentimiento específico.
- `tests/test_retell_v51.mjs`: tests integrados con SQLite D1 local y Retell simulados, cero llamadas reales.

### Cómo ejecutar QA sin servicios externos

```bash
node --no-warnings tests/test_retell_v51.mjs
node --no-warnings tests/test_v50.mjs
python tests/static_checks.py
```

**No** cargar el ZIP sobre la producción hasta autorización y pruebas reales. Más detalles en `docs/RETELL_V51_IMPLEMENTACION.md`.
