/* V50 · Documentation PDF and customer-owned status; no token in files, URLs, analytics or console. */
(()=>{'use strict';
const input=x=>String(x??'').normalize('NFD').replace(/[\u0300-\u036f]/g,'').replace(/[^\x20-\x7E]/g,' ').slice(0,250);
const money=c=>(Number(c||0)/100).toLocaleString('es-MX',{style:'currency',currency:'MXN'});
function buildPdf(lines){ // Minimal 1-page PDF with embedded standard font. All bytes are ASCII.
 const esc=s=>input(s).replace(/\\/g,'\\\\').replace(/\(/g,'\\(').replace(/\)/g,'\\)');
 const body=['BT','/F1 12 Tf','50 780 Td'];lines.slice(0,32).forEach((line,i)=>{if(i)body.push('0 -22 Td');body.push('('+esc(line)+') Tj');});body.push('ET');const stream=body.join('\n');
 const objects=[null,'<< /Type /Catalog /Pages 2 0 R >>','<< /Type /Pages /Count 1 /Kids [3 0 R] >>','<< /Type /Page /Parent 2 0 R /MediaBox [0 0 595 842] /Resources << /Font << /F1 5 0 R >> >> /Contents 4 0 R >>','<< /Length '+stream.length+' >>\nstream\n'+stream+'\nendstream','<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica >>'];
 let pdf='%PDF-1.4\n',offsets=[0];for(let i=1;i<objects.length;i++){offsets.push(pdf.length);pdf+=i+' 0 obj\n'+objects[i]+'\nendobj\n'}const xref=pdf.length;
 pdf+='xref\n0 '+objects.length+'\n0000000000 65535 f \n';for(let i=1;i<objects.length;i++)pdf+=String(offsets[i]).padStart(10,'0')+' 00000 n \n';pdf+='trailer\n<< /Root 1 0 R /Size '+objects.length+' >>\nstartxref\n'+xref+'\n%%EOF';return new Blob([pdf],{type:'application/pdf'});
}
const statuses={recibida:'Diagnostico recibido',calificacion:'Evaluacion inicial',visita:'Visita por coordinar',diseno:'Ingenieria y presupuesto',propuesta:'Propuesta en revision',contrato:'Contrato y anticipo',instalacion:'Instalacion',qa:'Pruebas y control de calidad',entregado:'Entrega',mantenimiento:'Posventa y mantenimiento',cancelado:'Solicitud cerrada'};
window.addEventListener('pluviam:proyecto',event=>{
 const {data:d,folio,token}=event.detail,zone=document.getElementById('project-result');if(!zone)return;
 const q=d.quote||{},p=d.paymentStates||{};
 const box=document.createElement('section');box.className='project-v50';
 const heading=document.createElement('h3');heading.textContent='Tu propuesta y pagos';box.append(heading);
 const detail=document.createElement('p');const isApproved=q.approved===true;
 detail.textContent=isApproved?`Inversion aprobada: ${money(q.amountCents)} · Anticipo 50%: ${money(Math.round(q.amountCents/2))} · Saldo 50%: ${money(q.amountCents-Math.round(q.amountCents/2))}`:'La propuesta contractual sigue pendiente de validacion. El diagnostico por si solo no autoriza un cobro.';box.append(detail);
 const pay=document.createElement('p');pay.textContent='Anticipo: '+(p.deposit==='paid'?'Confirmado':p.deposit?'En proceso / revisar conciliacion':'Pendiente')+' · Saldo: '+(p.final==='paid'?'Liquidado':p.final?'En proceso / revisar conciliacion':'Pendiente');box.append(pay);
 if(q.expired){const warn=document.createElement('p');warn.className='project-warning';warn.textContent='Cotizacion vencida: solicita revalidacion antes de pagar.';box.append(warn);}
 const actions=document.createElement('div');actions.className='project-actions';
 const follow=d.retellFollowup||{};
 let consentCheckbox=null,followMsg=null;
 if(follow.enabled&&follow.eligible){
  const consentLabel=document.createElement('label');consentLabel.className='project-retell-consent';
  consentCheckbox=document.createElement('input');consentCheckbox.type='checkbox';consentCheckbox.checked=false;
  const consentText=document.createElement('span');consentText.textContent='Autorizo voluntariamente que Valeria, asistente virtual con IA de PLUVIAM, me llame para dar seguimiento a esta cotización. Puedo revocar el permiso. La llamada puede ser facturable para PLUVIAM.';
  consentLabel.append(consentCheckbox,consentText);box.append(consentLabel);
  followMsg=document.createElement('p');followMsg.className='project-disclaimer';followMsg.setAttribute('role','status');box.append(followMsg);
 }
 const save=document.createElement('button');save.type='button';save.className='button button-primary';save.textContent='Guardar mi propuesta y pagar después';save.addEventListener('click',async()=>{
  const rows=['PLUVIAM | FICHA DE PROYECTO', 'Folio: '+folio,'Fecha de consulta: '+new Date().toLocaleDateString('es-MX'),'Estado: '+(statuses[d.stage]||d.stageLabel||'Pendiente'),'',
  isApproved?'Inversion aprobada: '+money(q.amountCents):'Monto: pendiente de aprobacion',isApproved?'Anticipo 50%: '+money(Math.round(q.amountCents/2)):'No hay cobro autorizado',
  isApproved?'Saldo 50%: '+money(q.amountCents-Math.round(q.amountCents/2)):'',q.expired?'Cotizacion vencida - revalidacion requerida':'',
  'Anticipo: '+(p.deposit==='paid'?'confirmado':'no confirmado'),'Saldo: '+(p.final==='paid'?'liquidado':'pendiente'),'',
  'Antes de pagar verifica contrato, alcance y condiciones.','Este comprobante de consulta NO es factura ni recibo de pago.','La clave privada de acceso nunca se incluye en este documento.'];
  const url=URL.createObjectURL(buildPdf(rows));const a=document.createElement('a');a.href=url;a.download='PLUVIAM_'+folio.replace(/[^A-Z0-9-]/g,'')+'_propuesta.pdf';a.click();setTimeout(()=>URL.revokeObjectURL(url),1200);
  // PDF conserva comportamiento original. Inscripción opcional por API separada, sin nuevo folio.
  if(consentCheckbox?.checked&&token&&follow.enabled){
   try{const r=await fetch('/api/lead-abandonment',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({folio,token,action:'consent',consent:true,consentVersion:follow.version})});const j=await r.json();
    if(!r.ok)throw Error(j.error||'No disponible');followMsg.textContent=j.alreadyRegistered?'Ya existe un seguimiento de esta cotización; no se programó otra llamada.':'Autorización guardada. Se evaluará el seguimiento según las condiciones de tu propuesta.';consentCheckbox.checked=false;
   }catch(e){followMsg.textContent='La ficha PDF se descargó, pero no se registró una llamada: '+(e.message||'error');}
  }
 });actions.append(save);
 const note=document.createElement('p');note.className='project-disclaimer';note.textContent='Tu propuesta ya permanece asociada a tu folio en PLUVIAM. Descarga el resumen; no compartas tu clave. El pago solo es posible después de aprobar el alcance y el contrato.';
 box.append(actions,note);zone.append(box);
 if(follow.consent&&['scheduled','deferred','claimed'].includes(follow.status)){
  const revoke=document.createElement('button');revoke.type='button';revoke.className='button';revoke.textContent='Revocar autorización de llamada automática';
  const status=document.createElement('p');status.className='project-disclaimer';
  revoke.addEventListener('click',async()=>{revoke.disabled=true;try{const r=await fetch('/api/lead-abandonment',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({folio,token,action:'revoke'})});if(!r.ok)throw Error('No se pudo revocar; inténtalo otra vez');status.textContent='Autorización revocada. Las llamadas pendientes se cancelaron.';revoke.hidden=true;}catch(e){status.textContent=e.message;revoke.disabled=false;}});
  box.append(revoke,status);
 }
 if(d.recordsAvailable){
   const rec=document.createElement('section');rec.className='project-records';const heading=document.createElement('h3');heading.textContent='Documentación y seguimiento';rec.append(heading);
   const docs=Array.isArray(d.documents)?d.documents:[];const events=Array.isArray(d.events)?d.events:[];
   if(!docs.length){const p=document.createElement('p');p.textContent='Todavía no hay documentos compartidos con este proyecto.';rec.append(p)}
   for(const doc of docs){const detail=document.createElement('details');const summary=document.createElement('summary');summary.textContent=doc.title+' · '+doc.kind;const text=document.createElement('p');text.textContent=doc.body;detail.append(summary,text);rec.append(detail)}
   if(events.length){const h=document.createElement('h4');h.textContent='Historial del proyecto';rec.append(h);const list=document.createElement('ol');for(const item of events){const li=document.createElement('li');li.textContent=[item.created_at,item.description].filter(Boolean).join(' · ');list.append(li)}rec.append(list)}
   zone.append(rec);
 }

});
})();
