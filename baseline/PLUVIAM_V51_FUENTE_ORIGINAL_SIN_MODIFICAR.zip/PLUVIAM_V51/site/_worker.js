
// Internal scenario — runs only in the Pages Worker, not in public asset JavaScript.
// PLUVIAM_PRICE_ENGINE_SHARED_BEGIN
const PUBLIC_PRICE_ESTIMATE=(()=>{const scope={};
/* Public hydrological estimator. Shows indicative investment scenarios by profile and expense band. */
(function(root){'use strict';
const segments=new Set(['vivienda','condominio','pyme','comercial','desarrollo','industrial','gobierno','civil','profesional']);
const plans={vivienda:'PLUVIAM HOME / RESERVA HÍDRICA',condominio:'PLUVIAM COLLECTIVE',pyme:'PLUVIAM BUSINESS',comercial:'PLUVIAM COMMERCIAL',desarrollo:'PLUVIAM BUILD',industrial:'PLUVIAM ENGINEERING',gobierno:'PLUVIAM CIVIC',civil:'PLUVIAM COMMUNITY',profesional:'PLUVIAM ACADEMY'};
const issueGuidance={desabasto:'Analizar respaldo ante cortes y continuidad del suministro.',pipas:'Dimensionar almacenamiento para reducir dependencia de pipas.',sarro:'Evaluar dureza y compatibilidad de materiales antes de elegir tratamiento.',calidad:'Solicitar análisis de calidad y tratamiento específico por uso.',costos:'Medir consumos y pérdidas para proponer ahorro con evidencia.',sustentabilidad:'Priorizar superficie de captación y aprovechamiento de lluvia.'};
const useGuidance={riego:'Separar circuitos para riego y uso exterior.',limpieza:'Definir puntos de limpieza con tratamiento apropiado.',sanitarios:'Evaluar circuito no potable dedicado a sanitarios.',operacion:'Evaluar seguridad de procesos y caudales del negocio.',potable:'Consumo humano sólo tras potabilización validada y análisis sanitario.'};
const reasons={vivienda:'Escenario residencial de referencia basado en el perfil y el gasto hídrico declarado.',condominio:'Escenario orientativo para operación compartida y áreas comunes.',pyme:'Escenario orientativo para negocio, continuidad operativa y almacenamiento.',comercial:'Escenario orientativo para superficie comercial y demanda operativa.',desarrollo:'Escenario orientativo para preingeniería, coordinación y obra por etapas.',industrial:'Escenario orientativo para infraestructura productiva y continuidad de planta.',gobierno:'Escenario orientativo para proyecto institucional sujeto a validación técnica.',civil:'Escenario orientativo para proyecto colectivo y operación comunitaria.',profesional:'Escenario orientativo canalizable para proyecto profesional o de cliente final.'};
const matrix={vivienda:{A:[95000,135000],B:[135000,185000],C:[185000,260000],D:[260000,380000]},condominio:{A:[220000,380000],B:[380000,650000],C:[650000,1050000],D:[1050000,1800000]},pyme:{A:[180000,320000],B:[320000,540000],C:[540000,880000],D:[880000,1400000]},comercial:{A:[350000,650000],B:[650000,1100000],C:[1100000,1900000],D:[1900000,3200000]},desarrollo:{A:[500000,900000],B:[900000,1600000],C:[1600000,3000000],D:[3000000,5500000]},industrial:{A:[700000,1200000],B:[1200000,2300000],C:[2300000,4800000],D:[4800000,9000000]},gobierno:{A:[300000,550000],B:[550000,950000],C:[950000,1700000],D:[1700000,3000000]},civil:{A:[250000,450000],B:[450000,800000],C:[800000,1500000],D:[1500000,2800000]},profesional:{A:[250000,450000],B:[350000,650000],C:[650000,1200000],D:[1200000,2200000]}};
function inferBand(expense){if(expense>=7000)return 'D'; if(expense>=3500)return 'C'; if(expense>=1800)return 'B'; if(expense>=800)return 'A'; return 'B'}
function adjustRange(range,s){let [min,max]=range;const area=Math.max(1,Math.min(300000,Number(s.roof)||100));const uses=Array.isArray(s.uses)?[...new Set(s.uses)]:String(s.uses||'riego').split(',').filter(Boolean);const storage=s.storage||'cisterna';let factor=1;if(area>150&&area<=400)factor+=0.08;else if(area>400&&area<=900)factor+=0.15;else if(area>900)factor+=0.24;if(storage==='ninguno'||storage==='no_se')factor+=0.06;if(uses.includes('sanitarios'))factor+=0.05;if(uses.includes('limpieza'))factor+=0.03;if(uses.includes('operacion'))factor+=0.06;if(uses.includes('potable'))factor+=0.09;min=Math.round(min*factor/1000)*1000;max=Math.round(max*factor/1000)*1000;return [min,max]}
function estimate(s){s=s||{};const segment=segments.has(s.segment)?s.segment:'vivienda';const area=Math.max(1,Math.min(300000,Number(s.roof)||100));const rainfall=Math.max(200,Math.min(2000,Number(s.rainfall)||800));const efficiency=Math.max(.4,Math.min(.9,Number(s.efficiency)||.75));const uses=Array.isArray(s.uses)?[...new Set(s.uses)]:String(s.uses||'riego').split(',').filter(Boolean);const monthlyExpense=Math.max(0,Math.min(100000000,Number(s.monthlyExpense)||0));const issues=Array.isArray(s.issues)?[...new Set(s.issues)].filter(x=>Object.hasOwn(issueGuidance,x)):[];const actions=[...issues.map(x=>issueGuidance[x]),...uses.filter(x=>Object.hasOwn(useGuidance,x)).map(x=>useGuidance[x])];const spendYear=monthlyExpense?monthlyExpense*12:null;const annualPotential=Math.round(area*rainfall*efficiency);const expenseUnknown=!monthlyExpense;const band=inferBand(monthlyExpense);let priceBand=null;if(band&&matrix[segment]){const [min,max]=adjustRange(matrix[segment][band],s);priceBand={min,center:Math.round((min+max)/2),max,band,assumedExpense:expenseUnknown};}return {segment,area,rainfall,efficiency,uses,monthlyExpense,annualPotential,spendYear,priceBand,actions,packageName:plans[segment]||'PLUVIAM / DISEÑO PERSONALIZADO',reason:reasons[segment],confidence:expenseUnknown?'Estimación exploratoria: banda de gasto B supuesta porque no se declaró un gasto.':'Escenario económico orientativo para conversación comercial.'}}
root.PLUVIAM_ENGINE={estimate};
})(scope);

return scope.PLUVIAM_ENGINE.estimate;})();
// PLUVIAM_PRICE_ENGINE_SHARED_END
/* PLUVIAM V40 Cloudflare Pages advanced-mode Worker.
 * No PII accepted until DB, Turnstile, approved notice & operator GO are configured.
 * All prices for payment are read from approved_quotes, NEVER browser estimates.
 */
const JSON_HEADERS={'Content-Type':'application/json; charset=utf-8','Cache-Control':'no-store','X-Content-Type-Options':'nosniff','Referrer-Policy':'no-referrer','X-Frame-Options':'DENY'};
const SEGMENTS=new Set(['vivienda','condominio','pyme','comercial','desarrollo','industrial','gobierno','civil','profesional']);
const STAGES={recibida:'Solicitud recibida',calificacion:'Evaluación inicial',visita:'Diagnóstico / visita pendiente',diseno:'Diseño y presupuesto en preparación',propuesta:'Propuesta disponible',contrato:'Contrato y confirmación',instalacion:'Instalación en proceso',qa:'Control de calidad',entregado:'Sistema entregado',mantenimiento:'Mantenimiento',cancelado:'Solicitud cerrada'};
function respond(o,status=200){return new Response(JSON.stringify(o),{status,headers:JSON_HEADERS})}
function norm(s,n=120){return typeof s==='string'?s.trim().slice(0,n):''}
function validNumber(n,min,max){return typeof n==='number'&&Number.isFinite(n)&&n>=min&&n<=max}
function originAllowed(req){let origin=req.headers.get('origin');return !origin||origin===new URL(req.url).origin}
function gate(env){return !!(env.DB&&env.TURNSTILE_SECRET&&env.TURNSTILE_SITE_KEY&&env.LEGAL_APPROVED==='true'&&env.LEADS_ENABLED==='true')}
function payGate(env){return !!(gate(env)&&env.PAYMENTS_ENABLED==='true')}
// Evita presentar el formulario como operativo si la migración D1 no está aplicada.
async function schemaReady(env){if(!env.DB)return false;try{for(const table of ['lead_cases','lead_diagnostics','lead_alerts'])await env.DB.prepare('SELECT '+(table==='lead_cases'?'folio':table==='lead_diagnostics'?'folio':'folio')+' FROM '+table+' LIMIT 1').first();return true}catch(_){return false}}

async function hash(v){const raw=new TextEncoder().encode(v);const dig=await crypto.subtle.digest('SHA-256',raw);return Array.from(new Uint8Array(dig),x=>x.toString(16).padStart(2,'0')).join('')}
async function hmacHex(key,text){const k=await crypto.subtle.importKey('raw',new TextEncoder().encode(key),{name:'HMAC',hash:'SHA-256'},false,['sign']);return Array.from(new Uint8Array(await crypto.subtle.sign('HMAC',k,new TextEncoder().encode(text))),x=>x.toString(16).padStart(2,'0')).join('')}
function safeSame(a,b){if(typeof a!=='string'||typeof b!=='string'||a.length!==b.length)return false;let v=0;for(let i=0;i<a.length;i++)v|=a.charCodeAt(i)^b.charCodeAt(i);return v===0}
async function validateTurnstile(request,env,token){const body=new URLSearchParams({secret:env.TURNSTILE_SECRET,response:token});const ip=request.headers.get('CF-Connecting-IP');if(ip)body.set('remoteip',ip);const r=await fetch('https://challenges.cloudflare.com/turnstile/v0/siteverify',{method:'POST',body});const v=await r.json();return v.success===true&&v.hostname===new URL(request.url).hostname}
async function limited(request,env){if(!env.ABUSE_PEPPER)return true;let ip=request.headers.get('CF-Connecting-IP');if(!ip)return true;const window=Math.floor(Date.now()/3600000);const signature=await hash(env.ABUSE_PEPPER+':'+ip+':'+window);await env.DB.prepare('DELETE FROM abuse_windows WHERE expires_at < ?').bind(new Date().toISOString()).run();const existing=await env.DB.prepare('SELECT attempts FROM abuse_windows WHERE signature=?').bind(signature).first();if(existing&&existing.attempts>=8)return false;const expire=new Date(Date.now()+86400000).toISOString();await env.DB.prepare('INSERT INTO abuse_windows(signature,attempts,expires_at) VALUES(?,1,?) ON CONFLICT(signature) DO UPDATE SET attempts=attempts+1').bind(signature,expire).run();return true}
async function bodyJson(request,max=12000){const len=Number(request.headers.get('content-length')||0);if(len>max)throw new Error('Tamaño de solicitud excesivo');const t=await request.text();if(t.length>max)throw new Error('Contenido demasiado largo');return JSON.parse(t)}
async function publicDiagnosis(req){let p;try{p=await bodyJson(req,2000)}catch{return respond({error:'Diagnóstico inválido'},400)}
 const seg=norm(p.segment,35),roof=Number(p.roof),storage=norm(p.storage,35),uses=Array.isArray(p.uses)?p.uses:[],issues=Array.isArray(p.issues)?p.issues:[],city=norm(p.city,50),expense=Number(p.monthlyExpense);
 if(!SEGMENTS.has(seg)||!validNumber(roof,1,300000)||!['cisterna','ninguno','no_se'].includes(storage)||uses.length>5||!uses.length||new Set(uses).size!==uses.length||uses.some(v=>!['riego','limpieza','sanitarios','operacion','potable'].includes(v))||issues.length>6||new Set(issues).size!==issues.length||issues.some(v=>!['desabasto','pipas','sarro','calidad','costos','sustentabilidad'].includes(v))||!validNumber(expense,0,100000000))return respond({error:'Dimensiones inválidas'},422);
 const x=PUBLIC_PRICE_ESTIMATE({segment:seg,roof,storage,uses,issues,city,monthlyExpense:expense,rainfall:800,efficiency:.75});
 return respond({pricingVersion:'V46-R7',packageName:x.packageName,reason:x.reason,priceBand:x.priceBand,actions:x.actions,confidence:x.confidence,annualPotential:x.annualPotential,assumption:'Precio orientativo, no constituye cotización ni genera obligación de pago.'});
}
async function identity(db,folio,token){if(!/^PLV-[A-Z0-9-]{8,46}$/.test(folio)||token.length>200||token.length<20)return null;let row=await db.prepare('SELECT folio,access_hash,status,next_step FROM lead_cases WHERE folio=?').bind(folio).first();if(!row||!safeSame(row.access_hash,await hash(token)))return null;return row}
// Alertas persistentes: registrar en D1 dentro de la misma transacción que el lead.
// El proveedor se llama con clave idempotente; fallas de correo NUNCA borran el prospecto.
async function deliverLeadAlert(env,folio){
 if(!env.RESEND_API_KEY||!env.RESEND_FROM||!env.DB)return 'pending';
 try{
  const row=await env.DB.prepare('SELECT folio,name,email,phone,segment,city FROM lead_cases WHERE folio=?').bind(folio).first();
  if(!row)return 'pending';
  const owner=norm(env.OPERATIONS_EMAIL||'pluviammx@gmail.com',180);
  if(!/^\S+@\S+\.\S+$/.test(owner))return 'pending';
  const message={from:env.RESEND_FROM,to:[owner],subject:'PLUVIAM | Nueva solicitud '+folio,
   text:['PLUVIAM · Nuevo expediente registrado','Folio: '+folio,'Nombre: '+row.name,'Correo: '+row.email,'WhatsApp: '+(row.phone||'No indicado'),'Perfil: '+row.segment,'Ciudad: '+row.city,'Panel privado: https://pluviam.pages.dev/admin.html','No compartas la clave privada del cliente.'].join('\n')};
  const response=await fetch('https://api.resend.com/emails',{method:'POST',headers:{Authorization:'Bearer '+env.RESEND_API_KEY,'Content-Type':'application/json','Idempotency-Key':'lead-'+folio},body:JSON.stringify(message),signal:AbortSignal.timeout(4500)});
  if(!response.ok)throw Error('Proveedor no confirmó la aceptación del aviso');
  await env.DB.prepare("UPDATE lead_alerts SET status='delivered',attempts=attempts+1,last_error=NULL,sent_at=CURRENT_TIMESTAMP WHERE folio=? AND status='pending'").bind(folio).run();
  return 'sent';
 }catch(_){try{await env.DB.prepare("UPDATE lead_alerts SET attempts=attempts+1,last_error='No confirmado por proveedor' WHERE folio=? AND status='pending'").bind(folio).run()}catch(__){}return 'pending'}
}
async function retryLeadAlerts(env){
 if(!env.DB||!env.RESEND_API_KEY||!env.RESEND_FROM)return {processed:0};
 const rows=await env.DB.prepare("SELECT folio FROM lead_alerts WHERE status='pending' AND attempts<5 ORDER BY created_at LIMIT 5").all();
 let processed=0;for(const item of (rows.results||[])){await deliverLeadAlert(env,item.folio);processed++}return {processed};
}
// Guardado previo de avances: sólo datos de cuestionario SIN identidad, tras consentimiento explícito.
async function saveDraft(request,env){
 if(!env.DB||env.LEGAL_APPROVED!=='true'||env.DRAFTS_ENABLED!=='true')return respond({error:'Avances en D1 todavía no habilitados.'},503);
 if(!(await limited(request,env)))return respond({error:'Inténtalo de nuevo más tarde.'},429);
 let d;try{d=await bodyJson(request,3500)}catch{return respond({error:'Avance inválido'},400)}
 const token=norm(d.token,125),stage=d.step,answers=d.answers;
 if(!/^[-a-f0-9]{36}-[-a-f0-9]{36}$/i.test(token)||d.consent!==true||!Number.isInteger(stage)||stage<0||stage>5||!answers||typeof answers!=='object'||Array.isArray(answers))return respond({error:'Revisa tu autorización y diagnóstico'},422);
 const allowed=new Set(['segment','city','cp','issues','uses','storage','roof','monthlyRange']);
 if(Object.keys(answers).some(k=>!allowed.has(k))||Object.values(answers).some(v=>typeof v==='string'&&v.length>100))return respond({error:'Datos no permitidos en el borrador'},422);
 const segment=norm(answers.segment,35),city=norm(answers.city,60);
 if(!SEGMENTS.has(segment)||!['CDMX','Guadalajara','Estado de México','Otra ciudad'].includes(city)||!['','A','B','C','D'].includes(answers.monthlyRange||''))return respond({error:'Datos del borrador inválidos'},422);
 if(!Array.isArray(answers.uses)||!Array.isArray(answers.issues)||answers.uses.length>6||answers.issues.length>6||answers.uses.some(v=>!['riego','limpieza','sanitarios','operacion','potable'].includes(v))||answers.issues.some(v=>!['desabasto','pipas','sarro','calidad','costos','sustentabilidad'].includes(v))||!/^\d{0,5}$/.test(String(answers.cp||''))||!['cisterna','ninguno','no_se'].includes(answers.storage)||!(answers.roof===''||answers.roof===null||Number.isFinite(Number(answers.roof))&&Number(answers.roof)>=1&&Number(answers.roof)<=300000))return respond({error:'Respuestas inválidas'},422);
 const snapshot=JSON.stringify(answers);if(snapshot.length>1600)return respond({error:'Diagnóstico demasiado largo'},422);
 const id=await hash(token);
 await env.DB.prepare('DELETE FROM lead_drafts WHERE expires_at < CURRENT_TIMESTAMP').run();
 await env.DB.prepare("INSERT INTO lead_drafts(draft_id,step,answers_json,expires_at) VALUES(?,?,?,datetime('now','+7 days')) ON CONFLICT(draft_id) DO UPDATE SET step=excluded.step,answers_json=excluded.answers_json,updated_at=CURRENT_TIMESTAMP,expires_at=excluded.expires_at").bind(id,stage,snapshot).run();
 return respond({saved:true,step:stage});
}
async function deleteDraft(request,env){
 if(!env.DB)return respond({saved:false},200);
 let d;try{d=await bodyJson(request,400)}catch{return respond({error:'Token inválido'},400)}
 const token=norm(d.token,125);if(!/^[-a-f0-9]{36}-[-a-f0-9]{36}$/i.test(token))return respond({error:'Token inválido'},422);
 await env.DB.prepare('DELETE FROM lead_drafts WHERE draft_id=?').bind(await hash(token)).run();return respond({deleted:true});
}
async function newLead(request,env){if(!gate(env)||!(await schemaReady(env)))return respond({error:'La recepción de solicitudes aún no está habilitada.'},503);if(!(await limited(request,env)))return respond({error:'Demasiadas solicitudes. Inténtalo más tarde.'},429);let s;try{s=await bodyJson(request)}catch{return respond({error:'Formulario inválido.'},400)};
 const name=norm(s.name,100),email=norm(s.email,180).toLowerCase(),phone=norm(s.phone,25),segment=norm(s.segment,40),city=norm(s.city,80),roof=s.roof,rainfall=s.rainfall,efficiency=s.efficiency,turn=norm(s.turnstile,5000);
 if(typeof s.uses!=='string'||!s.uses||s.uses.length>180||s.uses.split(',').length>6||s.uses.split(',').some(x=>!['riego','limpieza','sanitarios','operacion','varios','potable'].includes(x))||!validNumber(Number(s.monthlyExpense||0),0,100000000)||!s.consent||name.length<2||!/^\S+@\S+\.\S+$/.test(email)||!SEGMENTS.has(segment)||!validNumber(roof,1,300000)||!validNumber(rainfall,200,2000)||!validNumber(efficiency,.4,.9)||!turn||!['stripe','mercadopago','msi','bbva','btc','usdc','usdt','xrp','xlm','por_definir'].includes(s.payment))return respond({error:'Revisa los campos y el consentimiento.'},422);
 if(!(await validateTurnstile(request,env,turn)))return respond({error:'No se pudo validar la comprobación anti-spam.'},403);
 const a=s.answers,validIssue=['desabasto','pipas','sarro','calidad','costos','sustentabilidad'];
 if(!a||typeof a!=='object'||a.version!==1||a.segment!==segment||typeof a.city!=='string'||a.city.length>60||!['CDMX','Guadalajara','Estado de México','Otra ciudad'].includes(a.city)||typeof a.cp!=='string'||!/^\d{0,5}$/.test(a.cp)||!Array.isArray(a.issues)||a.issues.length>6||a.issues.some(i=>!validIssue.includes(i))||!Array.isArray(a.uses)||a.uses.join(',')!==s.uses||typeof a.roofIsExample!=='boolean'||!['','A','B','C','D'].includes(a.expenseRange)||!validNumber(Number(a.expenseEstimate),0,100000000)||!validNumber(Number(a.roiSaving??0),0,100000000)||!validNumber(Number(a.roiMaintenance??0),0,100000000)||JSON.stringify(a).length>3500)return respond({error:'Las respuestas del diagnóstico son inválidas.'},422);
 const expectedBand={A:1300,B:2650,C:5250,D:7000};if(Number(a.expenseEstimate)!==(expectedBand[a.expenseRange]||0)||Number(s.monthlyExpense||0)!==Number(a.expenseEstimate)||a.roofDeclared!==null&&Number(a.roofDeclared)!==roof||a.roofIsExample!==(a.roofDeclared===null))return respond({error:'Los datos económicos no coinciden con las respuestas.'},422);
 const folio='PLV-'+new Date().toISOString().slice(0,10).replaceAll('-','')+'-'+crypto.randomUUID().slice(0,8).toUpperCase(),accessToken=crypto.randomUUID()+'-'+crypto.randomUUID();
 const fields=[folio,await hash(accessToken),name,email,phone,segment,city,roof,norm(s.problem,35),norm(s.storage,35),norm(s.uses,180),norm(s.timing,35),rainfall,efficiency,norm(s.payment,35),Number(s.monthlyExpense||0),norm(env.CONSENT_VERSION||'borrador',55),new Date().toISOString()];
 await env.DB.batch([env.DB.prepare('INSERT INTO lead_cases(folio,access_hash,name,email,phone,segment,city,roof,objective,storage,usage,timeframe,rainfall,efficiency,preferred_payment,monthly_expense_mxn,consent_version,consent_at) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)').bind(...fields),env.DB.prepare('INSERT INTO lead_diagnostics(folio,answers_json) VALUES(?,?)').bind(folio,JSON.stringify(a)),env.DB.prepare("INSERT INTO lead_alerts(folio,status) VALUES(?,'pending')").bind(folio)]);
 const alert=await deliverLeadAlert(env,folio);await aggregateEvent(env,'cotizacion_solicitada');return respond({folio,accessToken,stage:'recibida',alert},201)
}
async function aggregateEvent(env,type){
 if(env.ANALYTICS_ENABLED!=='true'||!env.DB)return;
 const accepted=['cotizacion_solicitada','cotizacion_aprobada','anticipo_confirmado','saldo_liquidado','proyecto_activado'];
 if(!accepted.includes(type))return;
 try{await env.DB.prepare('INSERT INTO analytics_events_v50(id,event_type) VALUES(?,?)').bind(crypto.randomUUID(),type).run()}catch(_){}
}
async function dossierRecords(env,folio){
 if(env.PROJECT_DOCS_ENABLED!=='true')return {recordsAvailable:false,documents:[],events:[]};
 try{
  const ds=await env.DB.prepare('SELECT id,kind,title,body,created_at FROM project_documents_v50 WHERE folio=? ORDER BY created_at DESC LIMIT 30').bind(folio).all();
  const es=await env.DB.prepare('SELECT event_type,description,created_at FROM project_events_v50 WHERE folio=? ORDER BY created_at DESC LIMIT 50').bind(folio).all();
  return {recordsAvailable:true,documents:ds.results||[],events:es.results||[]};
 }catch(_){return {recordsAvailable:false,documents:[],events:[]}}
}
async function dossierEvent(env,folio,eventType,description){
 if(env.PROJECT_DOCS_ENABLED!=='true')return;
 try{await env.DB.prepare('INSERT INTO project_events_v50(id,folio,event_type,description) VALUES(?,?,?,?)').bind(crypto.randomUUID(),folio,eventType,norm(description,600)).run()}catch(_){}
}
async function project(req,env){if(!env.DB)return respond({error:'Servicio no configurado.'},503);let v;try{v=await bodyJson(req)}catch{return respond({error:'Datos inválidos'},400)};const row=await identity(env.DB,norm(v.folio,70),norm(v.token,200));if(!row)return respond({error:'Folio o clave no encontrados.'},404);
 const qr=await env.DB.prepare('SELECT id,amount_cents,currency,status,approved_at,approved_technical,approved_legal,accepted_by_customer FROM approved_quotes WHERE folio=?').bind(row.folio).first();const approved=qr&&qr.status==='approved'&&qr.approved_technical===1&&qr.approved_legal===1&&qr.accepted_by_customer===1;
 let paymentStates={};if(approved){const stateRows=await env.DB.prepare('SELECT stage,state FROM payment_attempts WHERE quote_id=?').bind(qr.id).all();for(const p of stateRows.results||[])paymentStates[p.stage]=p.state;}let options=[];const expired=!!(approved&&quoteExpired(env,qr));if(approved&&!expired&&payGate(env)){if(env.STRIPE_SECRET_KEY&&env.STRIPE_WEBHOOK_SECRET)options.push('stripe');if(env.MP_ACCESS_TOKEN&&env.MP_WEBHOOK_SECRET)options.push('mercadopago');if(env.BANK_PAYMENT_ENABLED==='true'&&/^\d{18}$/.test(env.BBVA_CLABE||'')&&env.BBVA_BENEFICIARY_NAME)options.push('bbva')};const records=await dossierRecords(env,row.folio);const retellFollowup=await retellEligibility(env,row.folio,qr?{...qr,approved:!!approved}:null,expired);return respond({retellFollowup,folio:row.folio,stage:row.status,stageLabel:STAGES[row.status]||'En evaluación',nextStep:row.next_step,quote:approved?{approved:true,expired,amountCents:qr.amount_cents,currency:qr.currency,approvedAt:qr.approved_at}:{approved:false},paymentOptions:options,paymentStates,...records})}
function admin(request,env){const token=request.headers.get('Authorization')||'';return env.ADMIN_TOKEN&&safeSame(token,'Bearer '+env.ADMIN_TOKEN)}
async function adminList(request,env){
 if(!env.DB||!admin(request,env))return respond({error:'No autorizado'},403);
 const rows=await env.DB.prepare(`SELECT l.folio,l.name,l.email,l.phone,l.segment,l.city,
 l.monthly_expense_mxn,l.preferred_payment,l.status,l.created_at,
 CASE WHEN d.folio IS NULL THEN 0 ELSE 1 END AS has_diagnosis,
 q.status AS quote_status,q.amount_cents AS quote_amount_cents,a.status AS alert_status,
 (SELECT p.state FROM payment_attempts p JOIN approved_quotes aq ON aq.id=p.quote_id
  WHERE aq.folio=l.folio ORDER BY p.created_at DESC LIMIT 1) AS payment_status
 FROM lead_cases l LEFT JOIN lead_diagnostics d ON d.folio=l.folio
 LEFT JOIN approved_quotes q ON q.folio=l.folio
 LEFT JOIN lead_alerts a ON a.folio=l.folio
 ORDER BY l.created_at DESC,l.folio DESC LIMIT 50`).all();
 await adminEvent(env.DB,'','leads:list');
 return respond({cases:rows.results||[],limit:50});
}
async function adminEvent(db,folio,action){await db.prepare('INSERT INTO admin_events(event_id,folio,action) VALUES(?,?,?)').bind(crypto.randomUUID(),folio,action).run()}

// Reliable post-payment handoff. Outbox is append-only per payment attempt, and
// payload intentionally excludes phone, email, address, and other customer PII.
async function paidOutbox(env,attemptId){
 const row=await env.DB.prepare(`SELECT p.id,p.stage,p.provider,p.expected_cents,q.folio FROM payment_attempts p JOIN approved_quotes q ON q.id=p.quote_id WHERE p.id=? AND p.state='paid'`).bind(attemptId).first();
 if(!row)return;
 if(row.stage==='deposit')await retellOnPaid(env,attemptId);
 await env.DB.prepare("INSERT OR IGNORE INTO automation_outbox(event_id,payment_attempt_id,folio,event_type,status) VALUES(?,?,?,?, 'pending')").bind(crypto.randomUUID(),row.id,row.folio,row.stage==='deposit'?'deposit_paid':'final_paid').run();
 await aggregateEvent(env,row.stage==='deposit'?'anticipo_confirmado':'saldo_liquidado');await dossierEvent(env,row.folio,'payment',row.stage==='deposit'?'Anticipo confirmado':'Saldo final confirmado');
 await deliverOutbox(env,row.id);
}
async function deliverOutbox(env,attemptId){
 if(env.ASTRA_ENABLED!=='true'||!env.ASTRA_WEBHOOK_URL||!env.ASTRA_WEBHOOK_SECRET)return false;
 let target;try{target=new URL(env.ASTRA_WEBHOOK_URL);if(target.protocol!=='https:'||target.username||target.password||target.hash) return false;}catch{return false}
 const row=await env.DB.prepare(`SELECT o.event_id,o.event_type,o.folio,o.status,p.stage,p.provider,p.expected_cents FROM automation_outbox o JOIN payment_attempts p ON p.id=o.payment_attempt_id WHERE o.payment_attempt_id=? AND p.state='paid'`).bind(attemptId).first();
 if(!row||row.status==='delivered')return row?.status==='delivered';
 const payload=JSON.stringify({eventId:row.event_id,eventType:row.event_type,folio:row.folio,stage:row.stage,provider:row.provider,amountCents:row.expected_cents,currency:'MXN',scheduleUrl:env.CALENDLY_SCHEDULING_URL||null});
 const signature=await hmacHex(env.ASTRA_WEBHOOK_SECRET,payload);
 try{
  const response=await fetch(target.toString(),{method:'POST',headers:{'Content-Type':'application/json','X-Pluviam-Signature':'sha256='+signature,'X-Idempotency-Key':row.event_id},body:payload,signal:AbortSignal.timeout(2500)});
  if(!response.ok)throw Error('Notification rejected');
  await env.DB.prepare("UPDATE automation_outbox SET status='delivered',attempts=attempts+1,last_error=NULL,delivered_at=CURRENT_TIMESTAMP WHERE payment_attempt_id=? AND status!='delivered'").bind(attemptId).run();
  return true;
 }catch(_){
  await env.DB.prepare("UPDATE automation_outbox SET status='pending',attempts=attempts+1,last_error='Delivery pending' WHERE payment_attempt_id=? AND status!='delivered'").bind(attemptId).run();
  return false;
 }
}

async function adminUpdate(request,env,path){if(!env.DB||!admin(request,env))return respond({error:'No autorizado'},403);if(path==='/api/admin/reintentar-alertas')return respond({ok:true,...await retryLeadAlerts(env)});let d;try{d=await bodyJson(request,10000)}catch{return respond({error:'Solicitud inválida'},400)};const folio=norm(d.folio,60);if(!/^PLV-[A-Z0-9-]{8,46}$/.test(folio))return respond({error:'Folio inválido'},400);const exists=await env.DB.prepare('SELECT folio FROM lead_cases WHERE folio=?').bind(folio).first();if(!exists)return respond({error:'Caso no encontrado'},404);
 if(path==='/api/admin/expediente'){const row=await env.DB.prepare('SELECT folio,name,email,phone,segment,city,roof,objective,storage,usage,timeframe,monthly_expense_mxn,preferred_payment,status,next_step,consent_version,consent_at,created_at FROM lead_cases WHERE folio=?').bind(folio).first();const detail=await env.DB.prepare('SELECT answers_json FROM lead_diagnostics WHERE folio=?').bind(folio).first();await adminEvent(env.DB,folio,'diagnostic:view');return respond({case:row,answers:detail?JSON.parse(detail.answers_json):null})}
 if(path==='/api/admin/documento'){
  if(env.PROJECT_DOCS_ENABLED!=='true')return respond({error:'Expediente documental pendiente de habilitación.'},503);
  const kind=norm(d.kind,30),title=norm(d.title,110),body=norm(d.body,5000);
  if(!['alcance','propuesta','contrato','manual','garantia','mantenimiento','entrega','pruebas'].includes(kind)||title.length<5||body.length<12)return respond({error:'Tipo, título o contenido inválidos.'},422);
  try{const id=crypto.randomUUID();await env.DB.prepare('INSERT INTO project_documents_v50(id,folio,kind,title,body) VALUES(?,?,?,?,?)').bind(id,folio,kind,title,body).run();await adminEvent(env.DB,folio,'document:'+kind);await dossierEvent(env,folio,'document',title);return respond({ok:true,id})}
  catch(_){return respond({error:'No se pudo guardar el documento. Revisa migración V50.'},503)}
 }
 if(path==='/api/admin/estado'){
  if(!STAGES[d.stage])return respond({error:'Etapa inválida'},422);
  // V50: server-side no-work-before-deposit invariant (cannot bypass via admin UI).
  const executableStages=new Set(['instalacion','qa','entregado','mantenimiento']);
  if(executableStages.has(d.stage)){
   const paidDeposit=await env.DB.prepare(`SELECT p.id FROM payment_attempts p JOIN approved_quotes q ON q.id=p.quote_id WHERE q.folio=? AND q.status='approved' AND q.approved_technical=1 AND q.approved_legal=1 AND q.accepted_by_customer=1 AND p.stage='deposit' AND p.state='paid' LIMIT 1`).bind(folio).first();
   if(!paidDeposit)return respond({error:'La ejecución está bloqueada hasta confirmar el anticipo, el alcance técnico y el contrato aprobado.'},409);
  }
  if(d.stage==='mantenimiento'){
   const finalPaid=await env.DB.prepare(`SELECT p.id FROM payment_attempts p JOIN approved_quotes q ON q.id=p.quote_id WHERE q.folio=? AND p.stage='final' AND p.state='paid' LIMIT 1`).bind(folio).first();
   if(!finalPaid)return respond({error:'Antes de cerrar y pasar a mantenimiento debe constar la liquidación final.'},409);
  }
  await env.DB.prepare('UPDATE lead_cases SET status=?,next_step=?,updated_at=CURRENT_TIMESTAMP WHERE folio=?').bind(d.stage,norm(d.nextStep,700),folio).run();await adminEvent(env.DB,folio,'stage:'+d.stage);await dossierEvent(env,folio,'stage',STAGES[d.stage]);if(d.stage==='instalacion')await aggregateEvent(env,'proyecto_activado');return respond({ok:true});
 }
 if(path==='/api/admin/reintentar-notificacion'){const attempt=norm(d.paymentAttemptId,75);if(!/^[a-zA-Z0-9-]{12,75}$/.test(attempt))return respond({error:'Identificador inválido'},422);const found=await env.DB.prepare(`SELECT p.id FROM payment_attempts p JOIN approved_quotes q ON q.id=p.quote_id WHERE q.folio=? AND p.id=? AND p.state='paid'`).bind(folio,attempt).first();if(!found)return respond({error:'Pago conciliado no encontrado'},404);return respond({ok:await deliverOutbox(env,attempt)});}
 if(path==='/api/admin/conciliar-bbva'){const ref=norm(d.bankReference,120),proof=norm(d.bankEvidenceId,180);if(!/^([A-Z0-9-]{8,65})$/.test(ref)||proof.length<6||d.confirmedByBank!==true)return respond({error:'Falta folio bancario verificado, comprobación y evidencia externa de conciliación.'},422);const pay=await env.DB.prepare("SELECT p.id,p.expected_cents,p.state FROM payment_attempts p JOIN approved_quotes q ON q.id=p.quote_id WHERE q.folio=? AND p.provider='bbva' AND p.provider_session=? AND p.state='awaiting_bank'").bind(folio,ref).first();if(!pay)return respond({error:'Pago no encontrado o ya conciliado'},409);if(Number(d.confirmedAmountCents)!==pay.expected_cents)return respond({error:'Importe de banco no coincide'},409);await env.DB.prepare("UPDATE payment_attempts SET state='paid',provider_payment_id=?,updated_at=CURRENT_TIMESTAMP WHERE id=? AND state='awaiting_bank'").bind(proof,pay.id).run();await adminEvent(env.DB,folio,'bbva-confirmed:'+proof);await paidOutbox(env,pay.id);return respond({ok:true,receipt:proof})}
 if(path==='/api/admin/cotizacion'){const amount=d.amountCents;if(!Number.isInteger(amount)||amount<10000||amount>100000000000)return respond({error:'Importe inválido en centavos MXN'},422);if(!d.technicalApproved||!d.legalApproved||!d.customerAccepted||!d.financeApproved)return respond({error:'Se requieren revisiones técnica, legal, financiera y aceptación del cliente antes de activar cobro.'},422);
 const refs=['rfq1Ref','rfq2Ref','technicalEvidenceRef','legalEvidenceRef','financeEvidenceRef','customerAcceptanceRef'];
 if(refs.some(k=>!/^([A-Za-z0-9:/._-]{10,230})$/.test(norm(d[k],230))))return respond({error:'Faltan dos RFQ comparables y referencias de soporte firmado verificables.'},422);
 if(d.rfq1Ref===d.rfq2Ref)return respond({error:'Las dos cotizaciones de proveedores deben ser diferentes.'},422);
 const fin=quoteFinancialGate(d);if(!fin.ok)return respond({error:fin.error,finance:fin},422);
 const old=await env.DB.prepare('SELECT id FROM approved_quotes WHERE folio=?').bind(folio).first();if(old){const pay=await env.DB.prepare("SELECT id FROM payment_attempts WHERE quote_id=? AND state IN ('created','redirected','awaiting_bank','paid')").bind(old.id).first();if(pay)return respond({error:'La propuesta tiene un pago iniciado: no se puede cambiar monto'},409)}
 const id=old?.id||crypto.randomUUID();await env.DB.prepare(`INSERT INTO approved_quotes(id,folio,amount_cents,currency,approved_technical,approved_legal,accepted_by_customer,status,summary,approved_at,gross_margin_bps,contribution_margin_bps,cash_after_deposit_cents,rfq_1_ref,rfq_2_ref,finance_evidence_ref,technical_evidence_ref,legal_evidence_ref,customer_acceptance_ref,finance_policy_version) VALUES(?,?,?,'MXN',1,1,1,'approved',?,CURRENT_TIMESTAMP,?,?,?,?,?,?,?,?,?,'V43') ON CONFLICT(folio) DO UPDATE SET amount_cents=excluded.amount_cents,approved_technical=1,approved_legal=1,accepted_by_customer=1,status='approved',summary=excluded.summary,approved_at=CURRENT_TIMESTAMP,updated_at=CURRENT_TIMESTAMP,finance_policy_version='V43',gross_margin_bps=excluded.gross_margin_bps,contribution_margin_bps=excluded.contribution_margin_bps,cash_after_deposit_cents=excluded.cash_after_deposit_cents,rfq_1_ref=excluded.rfq_1_ref,rfq_2_ref=excluded.rfq_2_ref,finance_evidence_ref=excluded.finance_evidence_ref,technical_evidence_ref=excluded.technical_evidence_ref,legal_evidence_ref=excluded.legal_evidence_ref,customer_acceptance_ref=excluded.customer_acceptance_ref`).bind(id,folio,amount,norm(d.summary,650),fin.grossMarginBps,fin.contributionMarginBps,fin.cashAfterDepositCents,norm(d.rfq1Ref,230),norm(d.rfq2Ref,230),norm(d.financeEvidenceRef,230),norm(d.technicalEvidenceRef,230),norm(d.legalEvidenceRef,230),norm(d.customerAcceptanceRef,230)).run();await adminEvent(env.DB,folio,'quote-approved:V43:'+String(fin.grossMarginBps)+':'+String(fin.contributionMarginBps));await dossierEvent(env,folio,'quote','Cotización aprobada bajo política financiera V43');await aggregateEvent(env,'cotizacion_aprobada');return respond({ok:true,quoteId:id,finance:{grossMarginBps:fin.grossMarginBps,contributionMarginBps:fin.contributionMarginBps,cashAfterDepositCents:fin.cashAfterDepositCents}})}
 return respond({error:'Ruta no encontrada'},404)
}
// V43: policy is server-side; price calculations from an anonymous questionnaire cannot authorize cash collection.
function quoteFinancialGate(d){
 const ints=['amountCents','directCostCents','operatingCostCents','warrantyReserveCents','cacCents','initialCashCents'];
 if(ints.some(k=>!Number.isSafeInteger(d[k])||d[k]<0))return {ok:false,error:'Faltan costos completos verificables expresados en centavos.'};
 const bps=Number.isInteger(d.gatewayFeeBps)?d.gatewayFeeBps:350, fixed=Number.isInteger(d.gatewayFixedCents)?d.gatewayFixedCents:300;
 if(bps<0||bps>2000||fixed<0||fixed>100000)return {ok:false,error:'Comisión pasarela inválida.'};
 const net=d.amountCents/1.16, fee=(d.amountCents*bps/10000+fixed)*1.16;
 const gm=Math.round((net-d.directCostCents)/net*10000);
 const contribution=net-d.directCostCents-d.operatingCostCents-d.warrantyReserveCents-d.cacCents-fee;
 const cm=Math.round(contribution/net*10000);
 const cash=d.amountCents*0.5/1.16-(d.amountCents*0.5*bps/10000+fixed)*1.16-d.initialCashCents;
 const minCash=300000; // $3,000 MXN operating buffer. Financial policy can only change via reviewed server release.
 return {ok:gm>=5500&&cm>=2500&&cash>=minCash, grossMarginBps:gm, contributionMarginBps:cm, cashAfterDepositCents:Math.round(cash),
  error:'Cotización bloqueada: margen bruto 55%, contribución 25% o colchón de caja inicial de $3,000 insuficientes.'};
}
function quoteExpired(env,q){
 if(env.QUOTE_VALIDITY_APPROVED!=='true')return false;
 const days=Number(env.QUOTE_VALID_DAYS);
 if(!Number.isInteger(days)||days<1||days>365||!q?.approved_at)return false;
 const date=new Date(String(q.approved_at).replace(' ','T').replace(/Z?$/,'Z'));
 return Number.isFinite(date.getTime())&&Date.now()>date.getTime()+days*86400000;
}
async function paymentContext(env,folio,token,stage){if(!payGate(env))return {error:'Pagos todavía no habilitados'};const row=await identity(env.DB,folio,token);if(!row)return {error:'Credenciales de proyecto inválidas'};const q=await env.DB.prepare('SELECT id,amount_cents,currency,approved_at FROM approved_quotes WHERE folio=? AND approved_technical=1 AND approved_legal=1 AND accepted_by_customer=1 AND finance_policy_version=\'V43\' AND gross_margin_bps>=5500 AND contribution_margin_bps>=2500 AND cash_after_deposit_cents>=300000 AND status=?').bind(folio,'approved').first();if(!q)return {error:'Este proyecto aún no tiene contrato y cotización aprobados.'};if(quoteExpired(env,q))return {error:'Esta cotización venció. Solicita su revalidación antes de realizar un pago.'};const dep=Math.round(q.amount_cents/2),amount=stage==='deposit'?dep:q.amount_cents-dep;
 if(stage==='final'){if(!['qa','entregado','mantenimiento'].includes(row.status))return {error:'El pago final requiere control de calidad o entrega registrada.'};const paid=await env.DB.prepare("SELECT id FROM payment_attempts WHERE quote_id=? AND stage='deposit' AND state='paid'").bind(q.id).first();if(!paid)return {error:'No procede el pago final antes de confirmar anticipo y aceptación de hitos'}}
 return {row,q,amount}}
async function checkout(request,env){if(!payGate(env))return respond({error:'Los pagos no están habilitados'},503);let d;try{d=await bodyJson(request)}catch{return respond({error:'Solicitud inválida'},400)};
 const provider=norm(d.provider,20),stage=norm(d.stage,10),folio=norm(d.folio,60),token=norm(d.token,200);if(!['stripe','mercadopago','bbva'].includes(provider)||!['deposit','final'].includes(stage))return respond({error:'Método o hito inválido'},422);
 const ctx=await paymentContext(env,folio,token,stage);if(ctx.error)return respond({error:ctx.error},409);
 const {q,amount}=ctx;const exists=await env.DB.prepare('SELECT id,state FROM payment_attempts WHERE quote_id=? AND stage=?').bind(q.id,stage).first();if(exists&&exists.state!=='failed')return respond({error:'Ya existe un intento de cobro para este hito. Contacta a PLUVIAM para conciliarlo.'},409);
 if(provider==='bbva'&&!(env.BANK_PAYMENT_ENABLED==='true'&&/^\d{18}$/.test(env.BBVA_CLABE||'')&&env.BBVA_BENEFICIARY_NAME))return respond({error:'Transferencia BBVA todavía sin datos bancarios completos verificados'},503);
 const id=crypto.randomUUID();if(exists){await env.DB.prepare("UPDATE payment_attempts SET id=?,state='created',provider=?,expected_cents=?,provider_session=NULL,provider_payment_id=NULL,updated_at=CURRENT_TIMESTAMP WHERE quote_id=? AND stage=?").bind(id,provider,amount,q.id,stage).run()}else{await env.DB.prepare('INSERT INTO payment_attempts(id,quote_id,stage,provider,expected_cents) VALUES(?,?,?,?,?)').bind(id,q.id,stage,provider,amount).run()}
 if(provider==='bbva'){const bankRef='PLV-'+q.id.replaceAll('-','').slice(0,14).toUpperCase()+'-'+(stage==='deposit'?'ANT':'FIN');await env.DB.prepare("UPDATE payment_attempts SET state='awaiting_bank',provider_session=?,updated_at=CURRENT_TIMESTAMP WHERE id=?").bind(bankRef,id).run();return respond({manual:true,bank:'BBVA México',accountName:env.BBVA_BENEFICIARY_NAME,clabe:env.BBVA_CLABE,bankRef,amountCents:amount,currency:'MXN',instructions:'Transferir solo el importe exacto de la cotización aprobada con la referencia indicada. El pago se reflejará únicamente cuando PLUVIAM confirme la recepción en el estado de cuenta; no enviar capturas como única prueba.'});}
 const origin=new URL(request.url).origin;let url,session='';try{if(provider==='stripe'){
  if(!env.STRIPE_SECRET_KEY||!env.STRIPE_WEBHOOK_SECRET)throw Error('Stripe no configurado');let p=new URLSearchParams();p.set('mode','payment');p.set('client_reference_id',id);p.set('success_url',origin+'/mi-proyecto.html');p.set('cancel_url',origin+'/mi-proyecto.html');p.set('line_items[0][price_data][currency]','mxn');p.set('line_items[0][price_data][unit_amount]',String(amount));p.set('line_items[0][price_data][product_data][name]','PLUVIAM · '+(stage==='deposit'?'Anticipo contractual':'Pago final')+' '+folio);p.set('line_items[0][quantity]','1');p.set('payment_intent_data[metadata][payment_attempt]',id);const r=await fetch('https://api.stripe.com/v1/checkout/sessions',{method:'POST',headers:{Authorization:'Bearer '+env.STRIPE_SECRET_KEY,'Content-Type':'application/x-www-form-urlencoded','Idempotency-Key':id},body:p});const j=await r.json();if(!r.ok||!j.url)throw Error('Stripe rechazó la creación de checkout');url=j.url;session=j.id;
 }else{
  if(!env.MP_ACCESS_TOKEN||!env.MP_WEBHOOK_SECRET)throw Error('Mercado Pago no configurado');const payload={items:[{title:'PLUVIAM · '+(stage==='deposit'?'Anticipo contractual':'Pago final'),quantity:1,currency_id:'MXN',unit_price:amount/100}],external_reference:id,back_urls:{success:origin+'/mi-proyecto.html',failure:origin+'/mi-proyecto.html',pending:origin+'/mi-proyecto.html'},auto_return:'approved',notification_url:origin+'/api/webhooks/mercadopago'};const r=await fetch('https://api.mercadopago.com/checkout/preferences',{method:'POST',headers:{Authorization:'Bearer '+env.MP_ACCESS_TOKEN,'Content-Type':'application/json','X-Idempotency-Key':id},body:JSON.stringify(payload)});const j=await r.json();if(!r.ok||!j.init_point)throw Error('Mercado Pago rechazó la preferencia');url=j.init_point;session=j.id;}}
 catch(err){await env.DB.prepare("UPDATE payment_attempts SET state='failed' WHERE id=?").bind(id).run();return respond({error:'No fue posible iniciar este cobro. No se generó cargo.'},502)}
 await env.DB.prepare("UPDATE payment_attempts SET state='redirected',provider_session=?,updated_at=CURRENT_TIMESTAMP WHERE id=? AND state='created'").bind(session,id).run();return respond({url});
}
async function stripeWebhook(request,env){if(!env.DB||!env.STRIPE_WEBHOOK_SECRET)return respond({error:'No configurado'},503);const signature=request.headers.get('Stripe-Signature')||'';const bits=Object.fromEntries(signature.split(',').map(x=>x.trim().split('=')));const raw=await request.text();if(!bits.t||!bits.v1||Math.abs(Date.now()/1000-Number(bits.t))>300)return respond({error:'Firma o tiempo inválido'},403);
 const v=await hmacHex(env.STRIPE_WEBHOOK_SECRET,bits.t+'.'+raw);if(!safeSame(v,bits.v1))return respond({error:'Firma inválida'},403);let event;try{event=JSON.parse(raw)}catch{return respond({error:'JSON inválido'},400)};
 if(event.type==='checkout.session.completed'&&event.data?.object?.payment_status==='paid'){const s=event.data.object;const id=norm(s.client_reference_id,90),amount=Number(s.amount_total);const pay=await env.DB.prepare('SELECT id,expected_cents,state FROM payment_attempts WHERE id=? AND provider=?').bind(id,'stripe').first();if(pay&&pay.expected_cents===amount&&s.currency==='mxn'&&['created','redirected'].includes(pay.state)){await env.DB.prepare("UPDATE payment_attempts SET state='paid',provider_payment_id=?,updated_at=CURRENT_TIMESTAMP WHERE id=?").bind(norm(s.payment_intent,140),id).run();await adminEvent(env.DB,'','stripe-paid:'+id);await paidOutbox(env,id)}}return respond({received:true})}
async function mpWebhook(request,env){if(!env.DB||!env.MP_WEBHOOK_SECRET||!env.MP_ACCESS_TOKEN)return respond({error:'No configurado'},503);const url=new URL(request.url),id=url.searchParams.get('data.id')||url.searchParams.get('id')||'',header=request.headers.get('x-signature')||'',rid=request.headers.get('x-request-id')||'';const parts=Object.fromEntries(header.split(',').map(s=>s.trim().split('=')));const ts=parts.ts||'';
 if(!/^\d{1,30}$/.test(id)||!rid||!ts||!parts.v1)return respond({error:'Notificación inválida'},403);const millis=Number(ts)<1e11?Number(ts)*1000:Number(ts);if(Math.abs(Date.now()-millis)>300000)return respond({error:'Tiempo inválido'},403);
 const check=await hmacHex(env.MP_WEBHOOK_SECRET,`id:${id.toLowerCase()};request-id:${rid};ts:${ts};`);if(!safeSame(check,parts.v1.toLowerCase()))return respond({error:'Firma inválida'},403);
 const r=await fetch('https://api.mercadopago.com/v1/payments/'+encodeURIComponent(id),{headers:{Authorization:'Bearer '+env.MP_ACCESS_TOKEN}});if(!r.ok)return respond({error:'No se pudo confirmar con pasarela'},502);const p=await r.json();if(p.status==='approved'){const ref=norm(p.external_reference,90);const pay=await env.DB.prepare('SELECT id,expected_cents,state FROM payment_attempts WHERE id=? AND provider=?').bind(ref,'mercadopago').first();if(pay&&pay.expected_cents===Math.round(Number(p.transaction_amount)*100)&&p.currency_id==='MXN'&&['created','redirected'].includes(pay.state)){await env.DB.prepare("UPDATE payment_attempts SET state='paid',provider_payment_id=?,updated_at=CURRENT_TIMESTAMP WHERE id=?").bind(id,ref).run();await adminEvent(env.DB,'','mp-paid:'+ref);await paidOutbox(env,ref)}}return respond({received:true})}

/* V46: embedded Mercado Pago CardPayment Brick. The server owns price and idempotency.
 * This never creates a quote, never changes contract status, and never handles raw PAN/CVV.
 * Production requires MP_PUBLIC_KEY, MP_ACCESS_TOKEN, MP_WEBHOOK_SECRET, DB,
 * TURNSTILE, LEGAL_APPROVED, LEADS_ENABLED and PAYMENTS_ENABLED.
 */
async function brickSetup(request,env){
 if(!payGate(env)||!env.MP_ACCESS_TOKEN||!env.MP_PUBLIC_KEY||!env.MP_WEBHOOK_SECRET)return respond({error:'El pago con tarjeta aún no está habilitado.'},503);
 let d;try{d=await bodyJson(request,3000)}catch{return respond({error:'Solicitud inválida'},400)}
 const folio=norm(d.folio,60),token=norm(d.token,200),stage=norm(d.stage,10);
 if(!['deposit','final'].includes(stage))return respond({error:'Hito inválido'},422);
 const ctx=await paymentContext(env,folio,token,stage);if(ctx.error)return respond({error:ctx.error},409);
 const q=ctx.q;let pa=await env.DB.prepare("SELECT id,state,provider,expected_cents FROM payment_attempts WHERE quote_id=? AND stage=?").bind(q.id,stage).first();
 if(pa && pa.state==='paid')return respond({error:'Este hito ya está pagado.'},409);
 if(pa && !['created','failed'].includes(pa.state))return respond({error:'Existe un pago pendiente de conciliación. Consulta el estado antes de reintentarlo.'},409);
 if(pa && (pa.provider!=='mercadopago'||pa.expected_cents!==ctx.amount) && pa.state!=='failed')return respond({error:'Existe una solicitud de cobro de otro método.'},409);
 if(!pa){const id=crypto.randomUUID();await env.DB.prepare("INSERT INTO payment_attempts(id,quote_id,stage,provider,expected_cents,state) VALUES(?,?,?,?,?,'created')").bind(id,q.id,stage,'mercadopago',ctx.amount).run();}
 else if(pa.state==='failed'){await env.DB.prepare("UPDATE payment_attempts SET id=?,provider='mercadopago',expected_cents=?,state='created',provider_session=NULL,provider_payment_id=NULL,updated_at=CURRENT_TIMESTAMP WHERE id=? AND state='failed'").bind(crypto.randomUUID(),ctx.amount,pa.id).run();}
 return respond({publicKey:env.MP_PUBLIC_KEY,amountCents:ctx.amount,currency:'MXN',stage});
}
async function brickPay(request,env){
 if(!payGate(env)||!env.MP_ACCESS_TOKEN||!env.MP_PUBLIC_KEY||!env.MP_WEBHOOK_SECRET)return respond({error:'Pago no habilitado'},503);
 let d;try{d=await bodyJson(request,8000)}catch{return respond({error:'Datos de pago inválidos'},400)}
 const stage=norm(d.stage,10),folio=norm(d.folio,60),token=norm(d.token,200);
 if(!['deposit','final'].includes(stage))return respond({error:'Hito inválido'},422);
 const ctx=await paymentContext(env,folio,token,stage);if(ctx.error)return respond({error:ctx.error},409);
 const f=d.formData||{},payToken=norm(f.token,230),method=norm(f.payment_method_id,70),email=norm(f.payer?.email,180),installments=Number(f.installments),issuer=f.issuer_id;
 if(!/^[A-Za-z0-9_-]{10,230}$/.test(payToken)||!/^[a-z0-9_-]{2,70}$/i.test(method)||!/^\S+@\S+\.\S+$/.test(email)||!Number.isInteger(installments)||installments<1||installments>18)return respond({error:'Datos de pago incompletos'},422);
 const pay=await env.DB.prepare("SELECT id,state,provider,expected_cents FROM payment_attempts WHERE quote_id=? AND stage=?").bind(ctx.q.id,stage).first();
 if(!pay||pay.state!=='created'||pay.provider!=='mercadopago'||pay.expected_cents!==ctx.amount)return respond({error:'Ya existe un pago en proceso o este hito no está preparado'},409);
 const locked=await env.DB.prepare("UPDATE payment_attempts SET state='redirected',updated_at=CURRENT_TIMESTAMP WHERE id=? AND state='created'").bind(pay.id).run();
 if(!locked.meta?.changes)return respond({error:'Pago ya enviado; revisa el estado antes de reintentar'},409);
 const payload={transaction_amount:ctx.amount/100,token:payToken,description:'PLUVIAM · '+(stage==='deposit'?'Anticipo contractual':'Finiquito')+' · '+folio,installments,payment_method_id:method,external_reference:pay.id,notification_url:new URL(request.url).origin+'/api/webhooks/mercadopago',payer:{email}};
 if(issuer!==undefined && issuer!==null && String(issuer).length<18)payload.issuer_id=issuer;
 const ident=f.payer?.identification;if(ident&&/^[A-Za-z]{2,8}$/.test(ident.type||'')&&typeof ident.number==='string'&&ident.number.length<40)payload.payer.identification={type:ident.type,number:ident.number};
 let p;try{const response=await fetch('https://api.mercadopago.com/v1/payments',{method:'POST',headers:{Authorization:'Bearer '+env.MP_ACCESS_TOKEN,'Content-Type':'application/json','X-Idempotency-Key':pay.id},body:JSON.stringify(payload)});p=await response.json();if(!response.ok){await env.DB.prepare("UPDATE payment_attempts SET state='failed',updated_at=CURRENT_TIMESTAMP WHERE id=? AND state='redirected'").bind(pay.id).run();return respond({error:'La pasarela no autorizó este intento. No repitas el pago sin revisar el estado.'},422)}}catch(_){return respond({error:'No se pudo verificar la respuesta de Mercado Pago. El intento quedó pendiente de conciliación; evita pagar otra vez.'},502)}
 const state=p.status==='approved'?'paid':p.status==='rejected'?'failed':'redirected';
 if(p.id&&p.currency_id==='MXN'&&Math.round(Number(p.transaction_amount)*100)===ctx.amount){await env.DB.prepare('UPDATE payment_attempts SET state=?,provider_payment_id=?,updated_at=CURRENT_TIMESTAMP WHERE id=?').bind(state,String(p.id),pay.id).run();await adminEvent(env.DB,folio,'mp-card-'+p.status+':'+pay.id);if(state==='paid')await paidOutbox(env,pay.id);return respond({status:p.status,confirmed:state==='paid',paymentId:String(p.id)});}return respond({error:'Pago sujeto a conciliación. Revisa el folio antes de repetir.'},202);
}

/* PLUVIAM V51. Módulo adicional aislado; desactivado por defecto.
   Todos los datos de importes/cotización se consultan en backend, jamás del navegador. */
const RETELL_CONSENT_VERSION='retell-followup-v1-2026-10-24';
const json=(v,s=200)=>new Response(JSON.stringify(v),{status:s,headers:{'Content-Type':'application/json; charset=utf-8','Cache-Control':'no-store','X-Content-Type-Options':'nosniff'}});
const str=(v,n=200)=>typeof v==='string'?v.trim().slice(0,n):'';
function enabled(e){return e.RETELL_ENABLED==='true' && e.RETELL_LAUNCH_APPROVED==='true' && e.RETELL_PRIVACY_APPROVED==='true' && e.RETELL_COST_APPROVED==='true' && e.RETELL_MX_OUTBOUND_APPROVED==='true' && Number(e.RETELL_MAX_CALLS_PER_DAY)>0 && e.RETELL_API_KEY && e.RETELL_AGENT_ID && e.RETELL_PHONE_NUMBER && e.DB;}
async function exists(e){try{await e.DB.prepare('SELECT folio FROM retell_consents_v51 LIMIT 1').first();await e.DB.prepare('SELECT id FROM retell_followups_v51 LIMIT 1').first();return true;}catch{return false;}}
function phoneValid(v){return /^(?:\+52[1-9]\d{9}|[1-9]\d{9}|52[1-9]\d{9})$/.test(String(v||'').replace(/[ ()-]/g,''));} // enfoque inicial: México, no asumir códigos de país
async function read(req){const raw=await req.text();if(raw.length>3500)throw Error('Too large');return JSON.parse(raw);}
async function paid(e,quoteId){return !!(await e.DB.prepare("SELECT id FROM payment_attempts WHERE quote_id=? AND stage='deposit' AND state='paid' LIMIT 1").bind(quoteId).first());}
async function retellEligibility(env,folio,quote,expired){
 const base={enabled:false,eligible:false,consent:false,status:null,version:RETELL_CONSENT_VERSION};
 if(!enabled(env)||!quote?.approved||expired||!quote.id||!await exists(env))return base;
 try{const consent=await env.DB.prepare('SELECT granted,revoked_at FROM retell_consents_v51 WHERE folio=?').bind(folio).first();const f=await env.DB.prepare('SELECT status FROM retell_followups_v51 WHERE quote_id=?').bind(quote.id).first();const hasPhone=await env.DB.prepare('SELECT phone FROM lead_cases WHERE folio=?').bind(folio).first();return {enabled:true,eligible:phoneValid(hasPhone?.phone)&&!await paid(env,quote.id),consent:consent?.granted===1&&!consent.revoked_at,status:f?.status||null,version:RETELL_CONSENT_VERSION};}catch{return base;}
}
async function retellCustomerApi(req,env,helpers){
 if(!env.DB)return json({error:'Servicio no configurado.'},503);
 let d;try{d=await read(req);}catch{return json({error:'Datos inválidos'},400);}
 const folio=str(d.folio,70),token=str(d.token,200);
 const row=await helpers.identity(env.DB,folio,token);
 if(!row)return json({error:'Folio o clave inválidos.'},403);
 if(!await exists(env))return json({error:'Servicio de llamadas no configurado.'},503);
 const action=str(d.action,12);
 if(action==='revoke'){
  await env.DB.batch([
   env.DB.prepare("UPDATE retell_consents_v51 SET granted=0,revoked_at=CURRENT_TIMESTAMP,updated_at=CURRENT_TIMESTAMP WHERE folio=?").bind(folio),
   env.DB.prepare("UPDATE retell_followups_v51 SET status='cancelled',updated_at=CURRENT_TIMESTAMP WHERE folio=? AND status IN ('scheduled','deferred','claimed')").bind(folio)
  ]);
  return json({ok:true,status:'revoked'});
 }
 if(action!=='consent'||d.consent!==true||str(d.consentVersion)!==RETELL_CONSENT_VERSION)return json({error:'Autorización expresa y versión vigente requeridas.'},422);
 if(!enabled(env))return json({error:'Llamadas automáticas desactivadas.'},503);
 const q=await env.DB.prepare("SELECT id,folio,status,approved_at,approved_technical,approved_legal,accepted_by_customer FROM approved_quotes WHERE folio=?").bind(folio).first();
 if(!q||q.status!=='approved'||q.approved_technical!==1||q.approved_legal!==1||q.accepted_by_customer!==1||helpers.quoteExpired(env,q))return json({error:'La cotización debe estar aprobada, aceptada y vigente.'},409);
 if(await paid(env,q.id))return json({error:'El anticipo ya está confirmado; no procede una llamada de rescate.'},409);
 const lead=await env.DB.prepare('SELECT phone FROM lead_cases WHERE folio=?').bind(folio).first();
 if(!phoneValid(lead?.phone))return json({error:'Se requiere teléfono mexicano en formato +52 y diez dígitos.'},422);
 const old=await env.DB.prepare('SELECT status FROM retell_followups_v51 WHERE quote_id=?').bind(q.id).first();
 if(old){if(old.status==='cancelled')return json({error:'Esta cotización tiene una autorización revocada y no se puede programar otra llamada automática. Contacta al equipo PLUVIAM.'},409);return json({ok:true,alreadyRegistered:true,status:old.status});}
 const delay=Number(env.RETELL_RESCUE_DELAY_SECONDS||180);
 if(!Number.isInteger(delay)||delay<180||delay>86400)return json({error:'Demora no configurada de manera segura.'},503);
 const id=crypto.randomUUID(),when=new Date(Date.now()+delay*1000).toISOString();
 // Transacción D1: un solo seguimiento por cotización. Fallos transitorios no deben romper PDF/checkout.
 try{
  await env.DB.batch([
   env.DB.prepare("INSERT INTO retell_consents_v51(folio,granted,consent_version,granted_at,revoked_at,updated_at) VALUES(?,1,?,CURRENT_TIMESTAMP,NULL,CURRENT_TIMESTAMP) ON CONFLICT(folio) DO UPDATE SET granted=1,consent_version=excluded.consent_version,granted_at=CURRENT_TIMESTAMP,revoked_at=NULL,updated_at=CURRENT_TIMESTAMP").bind(folio,RETELL_CONSENT_VERSION),
   env.DB.prepare("INSERT OR IGNORE INTO retell_followups_v51(id,folio,quote_id,status,scheduled_at) VALUES(?,?,?,'scheduled',?)").bind(id,folio,q.id,when)
  ]);
  const saved=await env.DB.prepare('SELECT id,status,scheduled_at FROM retell_followups_v51 WHERE quote_id=?').bind(q.id).first();return json({ok:true,status:saved.status,scheduledAt:saved.scheduled_at});
 }catch{return json({error:'No se pudo registrar la autorización; puedes conservar el PDF.'},503);}
}
// Cancelar llamadas pendientes cuando una conciliación REAL confirma el anticipo (operación idempotente).
async function retellOnPaid(env,paymentAttemptId){
 if(!env.DB)return;
 try{await env.DB.prepare("UPDATE retell_followups_v51 SET status='cancelled',updated_at=CURRENT_TIMESTAMP WHERE quote_id IN (SELECT quote_id FROM payment_attempts WHERE id=? AND stage='deposit' AND state='paid') AND status IN ('scheduled','deferred','claimed')").bind(paymentAttemptId).run();}catch(_){/* Si faltó la migración, la función de pagos permanece intacta. Cron vuelve a revisar el pago. */}
}


export default {async fetch(request,env){const path=new URL(request.url).pathname;if(path==='/_worker.js'||path==='/_worker.js.map')return new Response('Not found',{status:404});const legacy={'/contacto/':'/contacto.html','/contacto':'/contacto.html','/calculadora/':'/#experience','/calculadora':'/#experience','/nosotros/':'/','/nosotros':'/','/recorrido/':'/academia.html','/recorrido':'/academia.html'};if(Object.hasOwn(legacy,path))return Response.redirect(new URL(legacy[path],request.url).href,301);if(!path.startsWith('/api/'))return env.ASSETS.fetch(request);if(!originAllowed(request))return respond({error:'Origen no autorizado'},403);
 try{
  if(path==='/api/estado'&&request.method==='GET'){const databaseReady=await schemaReady(env),accepting=gate(env)&&databaseReady,payments=payGate(env)&&databaseReady;return respond({backend:true,accepting,turnstile:!!env.TURNSTILE_SITE_KEY,turnstileSiteKey:accepting?env.TURNSTILE_SITE_KEY:null,payments,drafts:!!(env.DB&&env.LEGAL_APPROVED==='true'&&env.DRAFTS_ENABLED==='true'),whatsAppNumber:/^[1-9]\d{9,14}$/.test(env.PUBLIC_WHATSAPP_NUMBER||'')?env.PUBLIC_WHATSAPP_NUMBER:null})}
  if(path==='/api/jobs/reintentar-alertas'&&request.method==='POST'){const auth=request.headers.get('Authorization')||'';if(!env.JOBS_TOKEN||!safeSame(auth,'Bearer '+env.JOBS_TOKEN))return respond({error:'No autorizado'},403);return respond({ok:true,...await retryLeadAlerts(env)});}
  if(path==='/api/borrador'&&request.method==='POST')return await saveDraft(request,env);
  if(path==='/api/borrador/borrar'&&request.method==='POST')return await deleteDraft(request,env);
  if(path==='/api/diagnostico'&&request.method==='POST')return await publicDiagnosis(request);
  if(path==='/api/solicitudes'&&request.method==='POST')return await newLead(request,env);
  if(path==='/api/proyecto'&&request.method==='POST')return await project(request,env);
  if(path==='/api/lead-abandonment'&&request.method==='POST')return await retellCustomerApi(request,env,{identity,quoteExpired});
  if(path==='/api/admin/salud'&&request.method==='GET'){if(!admin(request,env))return respond({error:'No autorizado'},403);const schema=await schemaReady(env);const checks={baseD1:!!env.DB,esquemaD1:schema,turnstile:!!(env.TURNSTILE_SECRET&&env.TURNSTILE_SITE_KEY),avisoAprobado:env.LEGAL_APPROVED==='true',recepcionActiva:env.LEADS_ENABLED==='true',correoConfigurado:!!(env.RESEND_API_KEY&&env.RESEND_FROM&&env.OPERATIONS_EMAIL),reintentoCorreo:!!env.JOBS_TOKEN,pagosHabilitados:env.PAYMENTS_ENABLED==='true'};return respond({registroListo:gate(env)&&schema,checks});}
  if(path==='/api/admin/metricas'&&request.method==='GET'){
   if(!admin(request,env)||!env.DB)return respond({error:'No autorizado'},403);
   if(env.ANALYTICS_ENABLED!=='true')return respond({enabled:false,events:[]});
   try{const rows=await env.DB.prepare('SELECT event_type,COUNT(*) AS total FROM analytics_events_v50 GROUP BY event_type').all();return respond({enabled:true,events:rows.results||[]})}catch(_){return respond({enabled:false,events:[],reason:'Ejecutar migración V50'},503)}
  }
  if(path==='/api/admin/retell'&&request.method==='GET'){
   if(!admin(request,env))return respond({error:'No autorizado'},403);
   if(!env.DB||!await exists(env))return respond({enabled:false,events:[]},503);
   const rows=await env.DB.prepare('SELECT folio,quote_id,status,scheduled_at,call_status,call_outcome,retell_call_id,attempts,created_at,updated_at FROM retell_followups_v51 ORDER BY created_at DESC LIMIT 50').all();
   return respond({enabled:!!enabled(env),events:rows.results||[]});
  }
  if(path==='/api/admin/clientes'&&request.method==='GET')return await adminList(request,env);
  if(path.startsWith('/api/admin/')&&request.method==='POST')return await adminUpdate(request,env,path);
  if(path==='/api/checkout'&&request.method==='POST')return await checkout(request,env);
  if(path==='/api/brick/setup'&&request.method==='POST')return await brickSetup(request,env);
  if(path==='/api/brick/pay'&&request.method==='POST')return await brickPay(request,env);
  if(path==='/api/webhooks/stripe'&&request.method==='POST')return await stripeWebhook(request,env);
  if(path==='/api/webhooks/mercadopago'&&request.method==='POST')return await mpWebhook(request,env);
  return respond({error:'Ruta API no encontrada'},404)
 }catch(e){return respond({error:'No se pudo procesar la solicitud. Intenta más tarde.'},500)}
 }};
